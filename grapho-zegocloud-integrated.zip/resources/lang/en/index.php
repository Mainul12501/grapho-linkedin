<?php

return [
    'login' => 'Login',
    'language' => 'Language',
];
