<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\RolePermissionManagement\Permission\PermissionCategoryController;
use App\Http\Controllers\Backend\RolePermissionManagement\Permission\PermissionController;
use App\Http\Controllers\Backend\RolePermissionManagement\Role\RoleController;
use App\Http\Controllers\Backend\ViewControllers\AdminViewController;


Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {

    Route::get('/dashboard', [AdminViewController::class, 'dashboard'])->name('dashboard');

    Route::resources([
        'permission-categories' => PermissionCategoryController::class,
        'permissions' => PermissionController::class,
        'roles' => RoleController::class,
//        'users' => UserController::class,
    ]);

});
