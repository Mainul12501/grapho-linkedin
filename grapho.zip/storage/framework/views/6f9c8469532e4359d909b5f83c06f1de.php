<!-- JQUERY JS -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- BOOTSTRAP JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/bootstrap/js/bootstrap.min.js"></script>




<!-- SIDE-MENU JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/sidemenu/sidemenu.js"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/p-scroll/perfect-scrollbar.js"></script>
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/p-scroll/pscroll.js"></script>

<!-- STICKY JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/js/sticky.js"></script>

<!-- INTERNAL SELECT2 JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/plugins/select2/select2.full.min.js"></script>



<!-- INTERNAL DATA-TABLES JS-->






<!-- COLOR THEME JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/js/themeColors.js"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/js/custom.js"></script>

<!-- CUSTOM PLUGIN CALL JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/js/custom/plugin-call.js"></script>

<!-- SWITCHER JS -->
<script src="<?php echo e(asset('/')); ?>backend/assets/switcher/js/switcher.js"></script>

<!-- custom added js -->
<!-- Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- Sweet Alert JS -->



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $(document).on('click', '.data-delete-form', function () {
        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Swal.fire(
                //     'Deleted!',
                //     'Your file has been deleted.',
                //     'success'
                // )
                $(this).parent().submit();
            }

        })
    })
</script>
<script>
    $(document).on('click', 'input[type="submit"]', function () {
        if (!$(this).hasClass('data-delete-form'))
        {
            $(this).attr('disabled', true);
            $(this).closest('form').submit();
        }
    })
    $(document).on('click', 'button[type="submit"]', function () {
        if (!$(this).hasClass('data-delete-form') )
        {

            $(this).attr('disabled', true);
            $(this).closest('form').submit();
        }
    })
</script>

<script>
    let base_url = <?php echo json_encode(url('/')); ?>+"/";
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(xhr, settings) {
            if (!settings.crossDomain) {
                settings.url = settings.url.replace(/^http:/, 'https:');
            }
        }
    });
</script>
<script>
    const date = new Date();
    // let currentDateTime = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate()+' '+date.getHours()+':'+date.getMinutes();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Adding leading zero if needed
    const day = date.getDate().toString().padStart(2, '0'); // Adding leading zero if needed
    const hours = date.getHours().toString().padStart(2, '0'); // Adding leading zero if needed
    const minutes = date.getMinutes().toString().padStart(2, '0'); // Adding leading zero if needed

    const currentDateTime = `${year}-${month}-${day} ${hours}:${minutes}`;
</script>
<script>

    function resetFromInputAndSelect(formAction = null, formId) {
        $("input:not(#formMethod,#formToken,[name='status'],[name='is_paid'],[name='is_featured'],[name='is_approved'],.check,[data-dtp='dtp_Nufud'])").each(function () {
            $(this).val('');
        })
        $('select option').each(function () {
            if ($(this).is(':selected'))
            {
                $(this).removeAttr('selected');
            }
        })
        $('form img').attr('src', '');
        $("textarea").each(function () {
            $(this).text('');
        })
        $('#'+formId).attr('action', formAction)
        $('#formMethod').remove()
        $('.select2').select2({
            placeholder: $(this).attr('data-placeholder'),
            allowClear: true
        });
    }
    function changeStatus(model_name, id, element) {
        $.ajax({
            
            method: "POST",
            data: {model_name: model_name, id:id},
            dataType: "JSON",
            success: function (message) {
                console.log(message);
                if(message.status == 'success')
                {
                    element.text(message.message).css('backgroundColor', '#8fbd56');
                    toastr.success('Status Changed Successfully.');
                }
            },
            error: function (error) {
                toastr.error(error);
            }
        })
    }
</script>

<?php if(Session::has('success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    </script>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('error')); ?>");
    </script>
<?php endif; ?>
<?php if(Session::has('customError')): ?>
    <script>
        Swal.fire({
            title: 'Error!',
            text: "<?php echo e(Session::get('customError')); ?>",
            icon: 'error',
            confirmButtonText: 'Ok'
        })
    </script>
<?php endif; ?>


<?php echo $__env->yieldPushContent('script'); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/includes/assets/js.blade.php ENDPATH**/ ?>