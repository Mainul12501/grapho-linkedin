<!doctype html>
<html lang="en" dir="ltr">
<head>

    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />

    <!-- meta info about website -->
    <meta name="description" content="Noa - Laravel Bootstrap 5 Admin & Dashboard Template">
    <meta name="author" content="BiddaBari">
    <meta name="keywords" content="Online Course">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- TITLE -->
    <title>SM Technology BD - <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('backend.includes.assets.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body class="ltr app sidebar-mini">

<!-- Switcher-->
<?php echo $__env->make('backend.includes.right-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- Switcher-->

<!-- GLOBAL-LOADER -->
<!--<div id="global-loader">-->
<!--    <img src="<?php echo e(asset('/')); ?>backend/assets/images/loader.svg" class="loader-img" alt="Loader">-->
<!--</div>-->
<!-- /GLOBAL-LOADER -->

<!-- PAGE -->
<div class="page">
    <div class="page-main">

        <!-- app-Header -->
        <?php echo $__env->make('backend.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- /app-Header -->

        <!--APP-SIDEBAR-->
        <?php echo $__env->make('backend.includes.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--/APP-SIDEBAR-->

        <!--app-content open-->
        <div class="app-content main-content mt-0">
            <div class="side-app">

                <!-- CONTAINER -->
                <div class="main-container container-fluid">

                    <?php echo $__env->yieldContent('body'); ?>

                </div>
            </div>
        </div>
        <!-- CONTAINER CLOSED -->
    </div>

    <!-- FOOTER -->
    <?php echo $__env->make('backend.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- FOOTER CLOSED -->

</div>
<!-- page -->

<!-- BACK-TO-TOP -->
<a href="#top" id="back-to-top"><i class="fa fa-long-arrow-up"></i></a>

<?php echo $__env->make('backend.includes.assets.js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/master.blade.php ENDPATH**/ ?>