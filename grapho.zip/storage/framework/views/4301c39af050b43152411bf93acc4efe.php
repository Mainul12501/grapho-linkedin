<?php $__env->startSection('title', 'Permission'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4 class="float-start text-white">Permissions</h4>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-permission')): ?>
                        <a href="<?php echo e(route('permissions.create')); ?>" class="rounded-circle text-white border-5 text-light f-s-22 btn position-absolute end-0 me-4">
                            <i class="fa-solid fa-circle-plus"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table" id="file-datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Category Name</th>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo $permission->permissionCategory->name; ?></td>
                                <td><?php echo e($permission->title); ?></td>
                                <td><?php echo e($permission->slug); ?></td>
                                <td><?php echo e($permission->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td class="">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-permission')): ?>
                                        <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="fa-solid fa-edit"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-permission')): ?>
                                        <form class="d-inline" action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" method="post" >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger data-delete-form">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('/')); ?>backend/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>backend/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>






















    <?php echo $__env->make('backend.includes.assets.plugin-files.datatable', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/role-management/permissions/index.blade.php ENDPATH**/ ?>