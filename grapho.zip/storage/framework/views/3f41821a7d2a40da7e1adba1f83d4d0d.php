<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('body'); ?>
    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Dashboard</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <!-- ROW-1 -->

    <!-- ROW-1 END-->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <!-- APEXCHART JS -->
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/apexcharts.js"></script>

    <!-- INDEX JS -->
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/index1.js"></script>


    <!-- Reply JS-->
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/reply.js"></script>

    <!-- CHART-CIRCLE JS-->
    <script src="<?php echo e(asset('/')); ?>backend/assets/plugins/circle-progress/circle-progress.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/single-view/dashboard/dashboard.blade.php ENDPATH**/ ?>