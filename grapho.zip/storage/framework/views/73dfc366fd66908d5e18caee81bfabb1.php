
<!-- App favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset('/')); ?>frontend/logo/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/')); ?>frontend/logo/favicon/favicon-16x16.png">

<!-- BOOTSTRAP CSS -->
<link id="style" href="<?php echo e(asset('/')); ?>backend/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />




<!-- HELPER CSS -->
<link href="<?php echo e(asset('/')); ?>backend/assets/css/helper.css" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="/backend/assets/css/style.css" rel="stylesheet" /> 
<link href="<?php echo e(asset('/')); ?>backend/assets/css/skin-modes.css" rel="stylesheet" />

<!--- FONT-ICONS CSS -->
<link href="/backend/assets/plugins/icons/icons.css" rel="stylesheet" />

<!-- INTERNAL Switcher css -->
<link href="<?php echo e(asset('/')); ?>backend/assets/switcher/css/switcher.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>backend/assets/switcher/demo.css" rel="stylesheet">

<!-- custom added css files -->
<!-- Toastr Css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- Sweet Alert -->
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet" />



<style>
    .img-16 {
        height: 16px;
        width: 16px;
    }

    thead tr th {
        text-transform:capitalize!important;
    }
    .card-header {
        padding: 0.8rem 1.6rem!important;
    }
    .select2-div .select2 {
        width: 100%!important;
    }
    td .badge:hover {
        background-color: #8fbd56!important;
        color: white;
    }
    form label {margin-bottom: 0!important;}

    #file-datatable_wrapper .dt-buttons{
        position: absolute !important;
        top: 0px !important;
        left: 136px !important;
    }
    .change-status { background-color: #8fbd56}
</style>
<?php echo $__env->yieldPushContent('style'); ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/includes/assets/css.blade.php ENDPATH**/ ?>