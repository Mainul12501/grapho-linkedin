<?php $__env->startSection('title', 'Permissions'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4 class="float-start text-light">Permission Create</h4>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="btn rounded-circle position-absolute end-0 me-3">
                        
                        <i class="fa-regular fa-file-lines fa-2x text-white"></i>
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($permission) ? route('permissions.update', $permission->id) : route('permissions.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($permission)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="mt-2 select2-div">
                            <label for="">Permission Category</label>
                            <select name="permission_category_id" class="form-control select2" required data-placeholder="<-- Select a Permission Category -->" id="">
                                <option value=""></option>
                                <?php $__currentLoopData = $permissionCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($permissionCategory->id); ?>" <?php echo e(isset($permission) && $permission->permission_category_id == $permissionCategory->id ? 'selected' : ''); ?>><?php echo e($permissionCategory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mt-2">
                            <label for="">Title</label>
                            <input type="text" name="title" class="form-control" value="<?php echo e(isset($permission) ? $permission->title : ''); ?>" />
                        </div>

                        <div class="mt-2">
                            <label for="">Is Published</label>
                            <div class="material-switch">
                                <input id="someSwitchOptionInfo" name="status" type="checkbox" <?php echo e(isset($permission) && $permission->status == 0 ? '' : 'checked'); ?>>
                                <label for="someSwitchOptionInfo" class="label-info"></label>
                            </div>
                        </div>
                        <div>
                            <input type="submit" class="btn btn-success btn-sm float-end" value="<?php echo e(isset($permission) ? 'Update' : 'Create'); ?> Permission" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>








<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/role-management/permissions/create.blade.php ENDPATH**/ ?>