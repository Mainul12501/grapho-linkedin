<?php $__env->startSection('title', 'Permission Categories'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4 class="float-start text-white">Permission Categories</h4>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-permission-category')): ?>
                        <a href="<?php echo e(route('permission-categories.create')); ?>" class="rounded-circle text-white border-5 text-light f-s-22 btn position-absolute end-0 me-4">
                            <i class="fa-solid fa-circle-plus"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table" id="file-datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Note</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $permissionCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($permissionCategory->name); ?></td>
                                <td><?php echo e($permissionCategory->slug); ?></td>
                                <td><?php echo $permissionCategory->note; ?></td>
                                <td><?php echo e($permissionCategory->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td class="">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-permission-category')): ?>
                                    <a href="<?php echo e(route('permission-categories.edit', $permissionCategory->id)); ?>" class="btn btn-sm btn-warning">
                                        <i class="fa-solid fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-permission-category')): ?>
                                        <form class="d-inline" action="<?php echo e(route('permission-categories.destroy', $permissionCategory->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger data-delete-form">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- DataTables -->


<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- Required datatable js -->




















<?php echo $__env->make('backend.includes.assets.plugin-files.datatable', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/role-management/permission-category/index.blade.php ENDPATH**/ ?>