<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <?php echo e(date('Y')); ?> <a href="#">SM Technology BD</a>. Designed with <span class="fa fa-heart text-danger"></span> & developed by <a href="#"> SM Technology BD </a> All rights reserved
            </div>
        </div>
    </div>
</footer>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\grapho\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>