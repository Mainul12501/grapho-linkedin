{{--<link href="{{ asset('/') }}backend/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />--}}
{{--<link href="{{ asset('/') }}backend/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />--}}


<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/dataTables.bootstrap5.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/dataTables.buttons.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/buttons.bootstrap5.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/jszip.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/pdfmake/pdfmake.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/pdfmake/vfs_fonts.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/buttons.html5.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/buttons.print.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/js/buttons.colVis.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="{{ asset('/') }}backend/assets/plugins/datatable/responsive.bootstrap5.min.js"></script>
<script src="{{ asset('/') }}backend/assets/js/table-data.js"></script>


{{--        // $('#datatable-buttons_wrapper').DataTable();--}}
