<?php

return [
    'login' => 'লগ ইন',
    'language' => 'ভাষা',
];
