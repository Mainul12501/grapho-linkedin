<?php

namespace App\Http\Controllers\Frontend\ZegoCloud;

use App\Events\CallAccepted;
use App\Events\CallEnded;
use App\Events\CallInitiated;
use App\Events\CallRejected;
use App\Helpers\FirebaseHelper;
use App\Helpers\ViewHelper;
use App\Http\Controllers\Controller;
use App\Models\Backend\Call;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class ZegoCloudController extends Controller
{
    /**
     * View call page
     */
    public function viewCallPage(Request $request)
    {
        $user = Auth::user();
        $roomId = $request->query('roomID');
        $callType = $request->query('type', 'video');

        if (!$user) {
            return redirect()->route('auth.user-login-page');
        }

        return view('frontend.zegocloud.index', [
            'user' => $user,
            'roomID' => $roomId,
            'callType' => $callType
        ]);
    }

    /**
     * Initiate a call
     */
    public function initiateCall(Request $request)
    {
        $request->validate([
            'receiver_id' => 'required|exists:users,id',
            'call_type' => 'required|in:audio,video',
        ]);

        $caller = ViewHelper::loggedUser();
        $receiver = User::findOrFail($request->receiver_id);

        if ($caller->id === $receiver->id) {
            return response()->json(['error' => 'You cannot call yourself'], 400);
        }

        $roomId = 'room_' . Str::random(20) . '_' . time();

        $call = Call::create([
            'caller_id' => $caller->id,
            'receiver_id' => $receiver->id,
            'room_id' => $roomId,
            'call_type' => $request->call_type,
            'status' => 'initiated',
        ]);

        broadcast(new CallInitiated($call))->toOthers();

        // Send Firebase push notification to receiver
        if ($receiver->fcm_token) {
            FirebaseHelper::sendIncomingCallNotification(
                receiverId: $receiver->id,
                callerName: $caller->name,
                callerId: $caller->id,
                callId: $call->id,
                roomId: $roomId,
                callType: $request->call_type,
                callerPhoto: $caller->profile_photo_url
            );
        }

        return response()->json([
            'success' => true,
            'call' => $call,
            'room_url' => route('zego.call-page', [
                'roomID' => $roomId,
                'type' => $request->call_type,
                'chatWith' => $receiver->id
            ])
        ]);
    }

    /**
     * Accept a call
     */
    public function acceptCall(Request $request, Call $call)
    {
        $user = Auth::user();

        if ($call->receiver_id !== $user->id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        if ($call->status !== 'initiated') {
            return response()->json(['error' => 'Call is not available'], 400);
        }

        $call->update([
            'status' => 'accepted',
            'started_at' => now(),
        ]);

        broadcast(new CallAccepted($call))->toOthers();

        // Send Firebase push notification to caller
        $caller = $call->caller;
        if ($caller->fcm_token) {
            FirebaseHelper::sendCallAcceptedNotification(
                callerId: $caller->id,
                receiverName: $user->name,
                receiverId: $user->id,
                callId: $call->id,
                roomId: $call->room_id
            );
        }

        return response()->json([
            'success' => true,
            'call' => $call,
            'room_url' => route('zego.call-page', [
                'roomID' => $call->room_id,
                'type' => $call->call_type,
                'chatWith' => $call->caller_id
            ])
        ]);
    }

    /**
     * Reject a call
     */
    public function rejectCall(Request $request, Call $call)
    {
        $user = Auth::user();

        if ($call->receiver_id !== $user->id) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        if (!in_array($call->status, ['initiated', 'ringing'])) {
            return response()->json(['error' => 'Call cannot be rejected'], 400);
        }

        $call->update([
            'status' => 'rejected',
            'ended_at' => now(),
        ]);

        broadcast(new CallRejected($call))->toOthers();

        // Send Firebase push notification to caller
        $caller = $call->caller;
        if ($caller->fcm_token) {
            FirebaseHelper::sendCallRejectedNotification(
                callerId: $caller->id,
                receiverName: $user->name,
                receiverId: $user->id,
                callId: $call->id
            );
        }

        return response()->json(['success' => true]);
    }

    /**
     * End a call
     */
    public function endCall(Request $request, Call $call)
    {
        $user = Auth::user();

        if (!in_array($user->id, [$call->caller_id, $call->receiver_id])) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        if ($call->status === 'ended') {
            return response()->json(['success' => true]);
        }

        $duration = null;
        if ($call->started_at) {
            $duration = now()->diffInSeconds($call->started_at);
        }

        $call->update([
            'status' => 'ended',
            'ended_at' => now(),
            'duration' => $duration,
        ]);

        $targetUserId = $user->id === $call->caller_id ? $call->receiver_id : $call->caller_id;
        broadcast(new CallEnded($call, $targetUserId))->toOthers();

        // Send Firebase push notification to the other user
        $targetUser = User::find($targetUserId);
        if ($targetUser && $targetUser->fcm_token) {
            FirebaseHelper::sendCallEndedNotification(
                userId: $targetUser->id,
                otherUserName: $user->name,
                otherUserId: $user->id,
                callId: $call->id,
                duration: $duration
            );
        }

        return response()->json(['success' => true]);
    }

    /**
     * Get call details
     */
    public function getCallDetails(Call $call)
    {
        $user = Auth::user();

        if (!in_array($user->id, [$call->caller_id, $call->receiver_id])) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        return response()->json([
            'call' => $call->load('caller', 'receiver')
        ]);
    }

    /**
     * Generate ZegoCloud token
     */
    public function generateToken(Request $request)
    {
        $request->validate([
            'room_id' => 'required|string',
        ]);

        $user = Auth::user();

        return response()->json([
            'success' => true,
            'user_id' => (string)$user->id,
            'user_name' => $user->name,
            'room_id' => $request->room_id,
            'app_id' => config('services.zegocloud.app_id'),
        ]);
    }
}
